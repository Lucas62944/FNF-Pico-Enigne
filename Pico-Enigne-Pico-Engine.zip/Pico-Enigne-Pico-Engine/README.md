# Friday Night Funkin' - Pico Engine
* please go here to download the other Pico Mods please https://gamebanana.com/mods/529389

## Credits
* Lucas - he was the person who programmed the Pico Engine

## Mod Proposal

* you are playing a new fnf mod vs Pico it has several engines and it is made just by one person who is me this mod has the main objective of bringing Pico as a player character and not just the mixes he received in V-Slice but bringing with it new music even if it is from another mod or even updating it, you can have in one place what is my proposal with the mod itself, I hope you like the mod and there will be more updates in the future with new things. until

## Future implementations
* In the next update there will be a character editor that can save the character's positions in the mod

![image](https://github.com/user-attachments/assets/c93ef213-7381-4216-b5fa-a38d02be2ad8)

and some more freeplay edits and some extra things

## Main menu

![image](https://github.com/user-attachments/assets/7b2d6a38-6d3f-4650-9460-689ff161c607)

There are some more things in the main menu like new Achievements
we will have story mode back with week 3 of Arrow funk and much more

## Settings

 ![image](https://github.com/user-attachments/assets/56cae3dd-d44b-40b2-9c58-26205b3d3927)

* Now the pico mod has an engine for the mod

## Pause Menu
![image](https://github.com/user-attachments/assets/cfde74b0-1ca0-4d73-8560-ce0028e44583)

## Score-Text
![Captura de tela 2025-02-23 131704](https://github.com/user-attachments/assets/dfc3bd85-88e5-4e85-8a63-413117aa1162)


## Updates
* the update now and 2.2-Pre-release
