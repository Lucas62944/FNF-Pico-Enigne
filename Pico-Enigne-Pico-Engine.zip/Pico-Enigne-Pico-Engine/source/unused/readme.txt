This is all most likely stuff intended to be used from base game and/or not used on Psych Engine.
I would suggest not messing with these, they're here just for archiving.