Put your .lua/.hx scripts here!

Scripts here run everywhere, if you want a script to play only for a specific song, put them in songs/song-name/script.lua or script.hx.