Put your stage JSON files here.

You can make a custom stage using the Stage Editor by pressing 7 in the main menu.