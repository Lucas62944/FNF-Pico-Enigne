Put your week JSON files here!

You can automatically generate a file if you use the Week Editor by pressing 7 in the main menu.

For more info, go here:
https://github.com/ShadowMario/FNF-PsychEngine/wiki/Adding-a-New-Week